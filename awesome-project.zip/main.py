def main():
    print("Привіт, світ!")

if __name__ == "__main__":
    main()